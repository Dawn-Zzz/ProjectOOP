#ifndef GAME_H_INCLUDED
#define GAME_H_INCLUDED

class Game {
	public:
		void run();
};

#endif
